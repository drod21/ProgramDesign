//
//  readline.h
//  
//
//  Created by Derek Rodriguez on 11/11/16.
//
//

#ifndef readline_h
#define readline_h

#include <stdio.h>
#include <ctype.h>

int read_line(char str[], int n);

#endif /* readline_h */
